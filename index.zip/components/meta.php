<meta charset="utf-8">
<link rel="shortcut icon" href="favico.png">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="BlackNET Free advanced and modern Windows botnet with a nice and secure PHP panel developed using VB.NET.">
<meta name="author" content="Black.Hacker">